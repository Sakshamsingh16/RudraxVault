# Rudrax Vault — GitHub Actions build

This repository builds a debug APK of Rudrax Vault using GitHub Actions.

## Build the APK
1. Open the **Actions** tab.
2. Select **Build Rudrax Vault APK**.
3. Press **Run workflow** (or push a change to `main`).
4. Open the completed workflow run and download **RudraxVault-debug-apk** from Artifacts.
5. Extract the artifact ZIP; it contains `app-debug.apk`. Transfer/install it on your Android phone.

## Project details
- Android app is in `RudraxVault/`.
- JDK 17, Gradle 8.9, Android SDK 35.
- Package name: `in.rudrax.vault`.

## Security notice
This is a starter project, not a security-audited release. Read `RudraxVault/README.md` before storing important files. In particular, clearing app data or uninstalling may permanently lose encrypted vault files and their key. Test with non-important files first.
