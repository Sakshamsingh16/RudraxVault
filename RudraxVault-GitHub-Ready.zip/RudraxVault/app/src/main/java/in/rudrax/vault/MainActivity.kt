package in.rudrax.vault

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

data class VaultItem(val id: String, val name: String, val mime: String, val size: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        clearPreviewCache(this)
        setContent { RudraxVaultApp(this) }
    }
}

private val Ink = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Violet = Color(0xFF8B5CF6)
private val Muted = Color(0xFFB8B8C8)

@Composable
fun RudraxVaultApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("rudrax_vault", Context.MODE_PRIVATE) }
    var setupComplete by remember { mutableStateOf(prefs.getBoolean("setup_complete", false)) }
    var unlocked by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("PIN") }
    var pin by remember { mutableStateOf("") }
    var pattern by remember { mutableStateOf(listOf<Int>()) }
    var setupPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var setupPattern by remember { mutableStateOf(listOf<Int>()) }
    var confirmPattern by remember { mutableStateOf(listOf<Int>()) }
    var stage by remember { mutableStateOf("pin") }
    var error by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(loadItems(prefs)) }
    var notice by remember { mutableStateOf("") }

    var showGallery by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        notice = if (r.resultCode == Activity.RESULT_OK) "Moved to vault. Originals removed from Gallery."
        else "Copies are safe in the vault, but originals are still in Gallery."
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMediaAccess(context)) showGallery = true else notice = "Gallery permission is needed to pick photos & videos."
    }
    fun openGallery() {
        if (hasMediaAccess(context)) showGallery = true else permLauncher.launch(mediaPerms())
    }
    fun requestDelete(uris: List<Uri>) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(context.contentResolver, uris)
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                var ok = 0
                uris.forEach { try { if (context.contentResolver.delete(it, null, null) > 0) ok++ } catch (_: Exception) {} }
                notice = if (ok == uris.size) "Moved to vault. Originals removed from Gallery."
                else "Copies are safe in the vault, but $ok/${uris.size} originals were removed."
            }
        } catch (e: Exception) {
            notice = "Copies are safe in the vault, but Gallery delete failed: ${e.message}"
        }
    }
    fun moveToVault(sel: List<GalleryMedia>) {
        scope.launch {
            busy = true
            val done = mutableListOf<Uri>()
            var failed = 0
            withContext(Dispatchers.IO) {
                sel.forEach { m -> try { importMedia(context, m); done += m.uri } catch (_: Exception) { failed++ } }
            }
            items = loadItems(prefs)
            busy = false
            showGallery = false
            if (failed > 0) notice = "$failed file(s) could not be imported."
            if (done.isNotEmpty()) requestDelete(done)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (!setupComplete) {
                if (stage == "pin") {
                    AuthScaffold("Welcome to Rudrax Vault", "Set a PIN (4–12 digits)") {
                        OutlinedTextField(setupPin, { setupPin = it.filter(Char::isDigit).take(12) },
                            label = { Text("Create PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(12) },
                            label = { Text("Confirm PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (setupPin.length < 4) error = "PIN must contain at least 4 digits"
                            else if (setupPin != confirmPin) error = "PINs do not match"
                            else { error = ""; stage = "pattern" }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Continue to Pattern") }
                        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                    }
                } else {
                    AuthScaffold("Create Pattern", "Tap at least 4 dots, then confirm it") {
                        PatternPad(pattern) { pattern = it }
                        Text("Selected dots: ${pattern.size}", color = Muted)
                        Button(onClick = {
                            if (pattern.distinct().size < 4) error = "Use at least 4 different dots"
                            else { setupPattern = pattern; pattern = emptyList(); stage = "confirm_pattern"; error = "" }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save Pattern") }
                        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                    }
                }
            } else if (!unlocked) {
                AuthScaffold("Rudrax Vault", "Unlock your private files") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = authMode == "PIN", onClick = { authMode = "PIN"; error = "" }, label = { Text("PIN") })
                        FilterChip(selected = authMode == "Pattern", onClick = { authMode = "Pattern"; error = "" }, label = { Text("Pattern") })
                    }
                    if (authMode == "PIN") {
                        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(12) },
                            label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (verifySecret(pin, prefs.getString("pin_hash", "") ?: "", prefs.getString("pin_salt", "") ?: "")) {
                                unlocked = true; pin = ""; error = ""
                            } else error = "Incorrect PIN"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
                    } else {
                        PatternPad(pattern) { pattern = it }
                        Button(onClick = {
                            if (verifySecret(pattern.joinToString(","), prefs.getString("pattern_hash", "") ?: "", prefs.getString("pattern_salt", "") ?: "")) {
                                unlocked = true; pattern = emptyList(); error = ""
                            } else { error = "Incorrect pattern"; pattern = emptyList() }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Unlock with Pattern") }
                    }
                    if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                }
            } else {
                HomeScreen(
                    items = items, notice = notice,
                    onLock = { clearPreviewCache(context); unlocked = false; notice = "" },
                    onAdd = { openGallery() },
                    onOpen = { item ->
                        try { openDecrypted(context, item) } catch (e: Exception) { notice = "Could not open file: ${e.message}" }
                    },
                    onDelete = { item ->
                        File(vaultDir(context), "${item.id}.rv").delete()
                        File(vaultDir(context), "${item.id}.th").delete()
                        removeItem(prefs, item.id)
                        items = loadItems(prefs)
                        notice = "File deleted from vault"
                    }
                )
                }
            }

            if (!setupComplete && stage == "confirm_pattern") {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Confirm Pattern") },
                    text = { Column {
                        Text("Draw the same pattern again.")
                        PatternPad(confirmPattern) { confirmPattern = it }
                    } },
                    confirmButton = {
                        TextButton(onClick = {
                            if (confirmPattern.distinct().size < 4 || confirmPattern != setupPattern) {
                                error = "Patterns do not match"; confirmPattern = emptyList()
                            } else {
                                saveSecret(prefs, "pin", setupPin)
                                saveSecret(prefs, "pattern", setupPattern.joinToString(","))
                                prefs.edit().putBoolean("setup_complete", true).apply()
                                setupComplete = true; unlocked = true
                                stage = "pin"; confirmPattern = emptyList()
                            }
                        }) { Text("Finish Setup") }
                    },
                    dismissButton = { TextButton(onClick = { stage = "pattern"; confirmPattern = emptyList() }) { Text("Back") }
                    }
                )
            }

            if (unlocked && showGallery) {
                GalleryPicker(busy = busy, onClose = { if (!busy) showGallery = false }, onConfirm = { moveToVault(it) })
            }
        }
    }
}


@Composable
private fun StatTile(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF191A28))
            .border(1.dp, Color(0x223F3A55), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFFB69AFF), modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 0.5.sp, maxLines = 1)
    }
}

@Composable
private fun AuthScaffold(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    val pulse by animateFloatAsState(
        targetValue = 1f, animationSpec = tween(900, easing = FastOutSlowInEasing), label = "logoPulse"
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF0B0C14), Color(0xFF19132D), Color(0xFF0B0C14)))
        )
    ) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 65.dp, end = 22.dp).size(170.dp)
            .background(Color(0x228B5CF6), CircleShape))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 70.dp).size(210.dp)
            .background(Color(0x168B5CF6), CircleShape))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 28.dp).imePadding(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(88.dp).scale(pulse)
                    .background(Brush.linearGradient(listOf(Color(0xFFB69AFF), Color(0xFF6D28D9))), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Security, contentDescription = "Rudrax Vault", tint = Color.White, modifier = Modifier.size(46.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text(title, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(subtitle, color = Color(0xFFB9B5CA), fontSize = 14.sp,
                modifier = Modifier.padding(top = 9.dp, bottom = 24.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(Color(0xDD191A29))
                    .border(1.dp, Color(0x448B5CF6), RoundedCornerShape(26.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                content = content
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color(0xFFB69AFF), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("PRIVATE STORAGE  •  ON THIS DEVICE", fontSize = 10.sp, color = Color(0xFF9C97B1), letterSpacing = 1.sp)
            }
        }
    }
}
@Composable
private fun PatternPad(selected: List<Int>, onChange: (List<Int>) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.animateContentSize()) {
        for (r in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp), modifier = Modifier.padding(vertical = 9.dp)) {
                for (c in 0..2) {
                    val index = r * 3 + c
                    val active = selected.contains(index)
                    Box(
                        Modifier.size(52.dp).border(1.dp, if (active) Color(0xFFD0BFFF) else Color(0x665C5670), CircleShape)
                            .background(if (active) Violet else Color(0xFF252338), CircleShape)
                            .clickable {
                                onChange(if (active) selected.filter { it != index } else selected + index)
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(if (active) "✓" else "•", color = Color.White, fontSize = if (active) 20.sp else 25.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Text("Tap dots in order", color = Muted, fontSize = 12.sp)
    }
}

private fun saveSecret(prefs: android.content.SharedPreferences, key: String, value: String) {
    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
    prefs.edit().putString("${key}_salt", salt.joinToString("") { "%02x".format(it) })
        .putString("${key}_hash", hash(value, salt)).apply()
}
private fun verifySecret(value: String, expected: String, saltHex: String): Boolean {
    if (expected.isBlank() || saltHex.isBlank()) return false
    val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    return MessageDigest.isEqual(hash(value, salt).toByteArray(), expected.toByteArray())
}
private fun hash(value: String, salt: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(salt + value.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
}

private fun vaultDir(context: Context): File = File(context.filesDir, "vault").apply { mkdirs() }

private fun getVaultKey(): SecretKey {
    val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val existing = ks.getKey("RudraxVaultKey", null) as? SecretKey
    if (existing != null) return existing
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(KeyGenParameterSpec.Builder(
        "RudraxVaultKey",
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
    ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true)
        .build())
    return generator.generateKey()
}

private fun importEncrypted(context: Context, uri: Uri): VaultItem {
    val resolver = context.contentResolver
    val displayName = queryName(resolver, uri) ?: "private_${System.currentTimeMillis()}"
    val mime = resolver.getType(uri) ?: "application/octet-stream"
    val id = java.util.UUID.randomUUID().toString()
    val dest = File(vaultDir(context), "$id.rv")
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getVaultKey())
    resolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Unable to read selected file" }
        FileOutputStream(dest).use { fileOut ->
            fileOut.write(cipher.iv)
            CipherOutputStream(fileOut, cipher).use { encryptedOut -> input.copyTo(encryptedOut) }
        }
    }
    val item = VaultItem(id, displayName, mime, dest.length())
    val prefs = context.getSharedPreferences("rudrax_vault", Context.MODE_PRIVATE)
    val array = JSONArray(prefs.getString("items", "[]"))
    array.put(JSONObject().put("id", item.id).put("name", item.name).put("mime", item.mime).put("size", item.size))
    prefs.edit().putString("items", array.toString()).apply()
    return item
}

private fun loadItems(prefs: android.content.SharedPreferences): List<VaultItem> {
    val out = mutableListOf<VaultItem>()
    val arr = JSONArray(prefs.getString("items", "[]"))
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        out += VaultItem(o.optString("id"), o.optString("name"), o.optString("mime"), o.optLong("size"))
    }
    return out
}
private fun removeItem(prefs: android.content.SharedPreferences, id: String) {
    val arr = JSONArray()
    loadItems(prefs).filter { it.id != id }.forEach {
        arr.put(JSONObject().put("id", it.id).put("name", it.name).put("mime", it.mime).put("size", it.size))
    }
    prefs.edit().putString("items", arr.toString()).apply()
}
private fun queryName(resolver: ContentResolver, uri: Uri): String? {
    return try {
        resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }
}

private fun decryptToCache(context: Context, item: VaultItem): File {
    val encrypted = File(vaultDir(context), "${item.id}.rv")
    require(encrypted.exists()) { "Encrypted file missing" }
    val temp = File(context.cacheDir, "preview_${item.id}")
    FileInputStream(encrypted).use { fileIn ->
        val iv = ByteArray(12)
        if (fileIn.read(iv) != 12) throw IOException("Invalid encrypted file")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getVaultKey(), GCMParameterSpec(128, iv))
        CipherInputStream(fileIn, cipher).use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        }
    }
    return temp
}
private fun openDecrypted(context: Context, item: VaultItem) {
    val temp = decryptToCache(context, item)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", temp)
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
private fun formatSize(size: Long): String = when {
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "${size / 1024} KB"
    else -> String.format("%.1f MB", size / (1024.0 * 1024.0))
}

// ---------- Gallery access ----------

data class GalleryMedia(val id: Long, val uri: Uri, val name: String, val mime: String, val isVideo: Boolean, val size: Long)

private fun mediaPerms(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
    Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    Build.VERSION.SDK_INT >= 30 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
}

private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

private fun hasMediaAccess(c: Context): Boolean = when {
    Build.VERSION.SDK_INT >= 34 ->
        (granted(c, Manifest.permission.READ_MEDIA_IMAGES) && granted(c, Manifest.permission.READ_MEDIA_VIDEO)) ||
            granted(c, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
    else -> mediaPerms().all { granted(c, it) }
}

private fun queryGallery(c: Context): List<GalleryMedia> {
    val out = mutableListOf<GalleryMedia>()
    val proj = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
        MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Files.FileColumns.SIZE)
    val sel = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
    val args = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(), MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
    try {
        c.contentResolver.query(MediaStore.Files.getContentUri("external"), proj, sel, args,
            "${MediaStore.Files.FileColumns.DATE_ADDED} DESC")?.use { cur ->
            while (cur.moveToNext()) {
                val id = cur.getLong(0)
                val isVideo = cur.getInt(3) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += GalleryMedia(id, ContentUris.withAppendedId(base, id), cur.getString(1) ?: "media_$id",
                    cur.getString(2) ?: if (isVideo) "video/mp4" else "image/jpeg", isVideo, cur.getLong(4))
            }
        }
    } catch (_: Exception) {}
    return out
}

@Suppress("DEPRECATION")
private fun loadGalleryThumb(c: Context, m: GalleryMedia, px: Int): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) c.contentResolver.loadThumbnail(m.uri, Size(px, px), null)
    else if (m.isVideo) MediaStore.Video.Thumbnails.getThumbnail(c.contentResolver, m.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
    else MediaStore.Images.Thumbnails.getThumbnail(c.contentResolver, m.id, MediaStore.Images.Thumbnails.MINI_KIND, null)
} catch (_: Exception) { null }

private fun importMedia(context: Context, m: GalleryMedia): VaultItem {
    val resolver = context.contentResolver
    val id = java.util.UUID.randomUUID().toString()
    val dest = File(vaultDir(context), "$id.rv")
    try {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getVaultKey())
        resolver.openInputStream(m.uri).use { input ->
            requireNotNull(input) { "Unable to read file" }
            FileOutputStream(dest).use { fileOut ->
                fileOut.write(cipher.iv)
                CipherOutputStream(fileOut, cipher).use { input.copyTo(it) }
            }
        }
        loadGalleryThumb(context, m, 360)?.let { bmp ->
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            encryptBytes(bos.toByteArray(), File(vaultDir(context), "$id.th"))
        }
    } catch (e: Exception) {
        dest.delete(); File(vaultDir(context), "$id.th").delete()
        throw e
    }
    val item = VaultItem(id, m.name, m.mime, dest.length())
    val prefs = context.getSharedPreferences("rudrax_vault", Context.MODE_PRIVATE)
    val array = JSONArray(prefs.getString("items", "[]"))
    array.put(JSONObject().put("id", item.id).put("name", item.name).put("mime", item.mime).put("size", item.size))
    prefs.edit().putString("items", array.toString()).commit()
    return item
}

private fun encryptBytes(data: ByteArray, dest: File) {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getVaultKey())
    FileOutputStream(dest).use { it.write(cipher.iv); it.write(cipher.doFinal(data)) }
}

private fun decryptBytes(src: File): ByteArray {
    val all = src.readBytes()
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, getVaultKey(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
    return cipher.doFinal(all, 12, all.size - 12)
}

private fun clearPreviewCache(context: Context) {
    context.cacheDir.listFiles()?.filter { it.name.startsWith("preview_") }?.forEach { it.delete() }
}

// ---------- UI ----------

@Composable
private fun GalleryPicker(busy: Boolean, onClose: () -> Unit, onConfirm: (List<GalleryMedia>) -> Unit) {
    val context = LocalContext.current
    var media by remember { mutableStateOf<List<GalleryMedia>?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var filter by remember { mutableStateOf("All") }
    LaunchedEffect(Unit) { media = withContext(Dispatchers.IO) { queryGallery(context) } }
    BackHandler(onBack = onClose)

    val all = media
    val shown = all?.filter { filter == "All" || (filter == "Photos" && !it.isVideo) || (filter == "Videos" && it.isVideo) } ?: emptyList()

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0C14))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Select to hide", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(if (selected.isEmpty()) "Tap photos & videos" else "${selected.size} selected", color = Muted, fontSize = 12.sp)
                }
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Photos", "Videos").forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f) })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    all == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Violet)
                    shown.isEmpty() -> Text("No media found", color = Muted, modifier = Modifier.align(Alignment.Center))
                    else -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 90.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        gridItems(shown, key = { it.id }) { m ->
                            val isSel = m.id in selected
                            val thumb by produceState<Bitmap?>(null, m.id) {
                                value = withContext(Dispatchers.IO) { loadGalleryThumb(context, m, 256) }
                            }
                            Box(
                                Modifier.aspectRatio(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1B1D2A))
                                    .clickable { selected = if (isSel) selected - m.id else selected + m.id }
                            ) {
                                thumb?.let {
                                    Image(it.asImageBitmap(), null, Modifier.fillMaxSize().scale(if (isSel) 0.86f else 1f).clip(RoundedCornerShape(if (isSel) 10.dp else 0.dp)),
                                        contentScale = ContentScale.Crop)
                                }
                                if (m.isVideo) Box(Modifier.align(Alignment.BottomStart).padding(5.dp).size(22.dp).background(Color(0x99000000), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp)
                                    .background(if (isSel) Violet else Color(0x55000000), CircleShape)
                                    .border(1.5.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
                                    if (isSel) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
        AnimatedVisibility(visible = selected.isNotEmpty(), modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut()) {
            Button(
                onClick = { onConfirm((all ?: emptyList()).filter { it.id in selected }) },
                enabled = !busy,
                modifier = Modifier.navigationBarsPadding().padding(16.dp).fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Violet)
            ) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp)); Text("Encrypting…", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Filled.Lock, null); Spacer(Modifier.width(8.dp))
                    Text("Move ${selected.size} to Vault", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    items: List<VaultItem>, notice: String,
    onLock: () -> Unit, onAdd: () -> Unit, onOpen: (VaultItem) -> Unit, onDelete: (VaultItem) -> Unit
) {
    val context = LocalContext.current
    var toDelete by remember { mutableStateOf<VaultItem?>(null) }
    val full = GridItemSpan(2)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B0C14), Color(0xFF11101F), Color(0xFF0B0C14))))) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { full }) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Color(0xFFB69AFF), Color(0xFF6D28D9))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Security, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Rudrax Vault", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("Your private space", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = onLock, modifier = Modifier.background(Color(0x228B5CF6), CircleShape)) {
                        Icon(Icons.Filled.Lock, "Lock vault", tint = Color(0xFFB69AFF))
                    }
                }
            }
            item(span = { full }) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF4A2D8F), Color(0xFF2A1F52), Color(0xFF171526))))
                        .border(1.dp, Color(0x668B5CF6), RoundedCornerShape(26.dp)).padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("PRIVATE BY DESIGN", color = Color(0xFFD0BFFF), fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Keep your moments\njust for you.", fontSize = 22.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("AES-256 encrypted • Stored on device", color = Color(0xFFC2BAD8), fontSize = 11.sp)
                    }
                    Box(Modifier.size(70.dp).background(Color(0x33FFFFFF), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Lock, null, tint = Color(0xFFE6DAFF), modifier = Modifier.size(36.dp))
                    }
                }
            }
            item(span = { full }) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile("PRIVATE FILES", items.size.toString(), Icons.Filled.Security, Modifier.weight(1f))
                    StatTile("PHOTOS", items.count { it.mime.startsWith("image/") }.toString(), Icons.Filled.Photo, Modifier.weight(1f))
                    StatTile("VIDEOS", items.count { it.mime.startsWith("video/") }.toString(), Icons.Filled.Videocam, Modifier.weight(1f))
                }
            }
            item(span = { full }) {
                Column {
                    Button(
                        onClick = onAdd, modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(20.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)
                    ) {
                        Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp))
                        Text("Add photos & videos", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text("Selected files move from Gallery into the vault, encrypted.", color = Muted, fontSize = 11.sp,
                        modifier = Modifier.padding(top = 8.dp))
                    AnimatedVisibility(visible = notice.isNotEmpty(), enter = fadeIn() + slideInVertically(), exit = fadeOut()) {
                        Text(notice, color = Color(0xFFD0BFFF), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    }
                }
            }
            item(span = { full }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your vault", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
                    Text("${items.size} ${if (items.size == 1) "item" else "items"}", color = Muted, fontSize = 12.sp)
                }
            }
            if (items.isEmpty()) {
                item(span = { full }) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFF171825))
                            .border(1.dp, Color(0x223F3A55), RoundedCornerShape(22.dp)).padding(vertical = 28.dp, horizontal = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.LockOpen, null, tint = Color(0xFFB69AFF), modifier = Modifier.size(38.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Your vault is empty", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        Text("Add your first photo or video to get started.", color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                gridItems(items, key = { it.id }) { item ->
                    val isVideo = item.mime.startsWith("video/")
                    val thumb by produceState<Bitmap?>(null, item.id) {
                        value = withContext(Dispatchers.IO) {
                            try {
                                val f = File(vaultDir(context), "${item.id}.th")
                                if (f.exists()) decryptBytes(f).let { BitmapFactory.decodeByteArray(it, 0, it.size) } else null
                            } catch (_: Exception) { null }
                        }
                    }
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(20.dp)).background(Color(0xFF191A28))
                            .border(1.dp, Color(0x223F3A55), RoundedCornerShape(20.dp))
                            .clickable { onOpen(item) }
                    ) {
                        val t = thumb
                        if (t != null) Image(t.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Icon(if (isVideo) Icons.Filled.PlayCircle else Icons.Filled.Photo, null,
                            tint = Color(0xFFB69AFF), modifier = Modifier.align(Alignment.Center).size(40.dp))
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)), startY = 150f)))
                        if (isVideo) Box(Modifier.align(Alignment.Center).size(42.dp).background(Color(0x88000000), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Column(Modifier.align(Alignment.BottomStart).padding(10.dp).fillMaxWidth(0.75f)) {
                            Text(item.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(formatSize(item.size), color = Color(0xFFD0D0DC), fontSize = 10.sp)
                        }
                        IconButton(onClick = { toDelete = item }, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(34.dp)
                            .background(Color(0x88000000), CircleShape)) {
                            Icon(Icons.Filled.DeleteOutline, "Delete from vault", tint = Color(0xFFFF8B9A), modifier = Modifier.size(19.dp))
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete from vault?") },
            text = { Text("\"${item.name}\" will be permanently deleted. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { onDelete(item); toDelete = null }) { Text("Delete", color = Color(0xFFFF7777)) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}
