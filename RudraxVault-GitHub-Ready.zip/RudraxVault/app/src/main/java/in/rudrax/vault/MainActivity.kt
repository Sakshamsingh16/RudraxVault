package in.rudrax.vault

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

data class VaultItem(val id: String, val name: String, val mime: String, val size: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RudraxVaultApp(this) }
    }
}

private val Ink = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Violet = Color(0xFF8B5CF6)
private val Muted = Color(0xFFB8B8C8)

@Composable
fun RudraxVaultApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("rudrax_vault", Context.MODE_PRIVATE) }
    var setupComplete by remember { mutableStateOf(prefs.getBoolean("setup_complete", false)) }
    var unlocked by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("PIN") }
    var pin by remember { mutableStateOf("") }
    var pattern by remember { mutableStateOf(listOf<Int>()) }
    var setupPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var setupPattern by remember { mutableStateOf(listOf<Int>()) }
    var confirmPattern by remember { mutableStateOf(listOf<Int>()) }
    var stage by remember { mutableStateOf("pin") }
    var error by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(loadItems(prefs)) }
    var pendingDelete by remember { mutableStateOf<Uri?>(null) }
    var pendingDeleteName by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            try {
                val added = importEncrypted(context, uri)
                items = loadItems(prefs)
                notice = "Encrypted copy saved: ${added.name}"
                pendingDelete = uri
                pendingDeleteName = added.name
            } catch (e: Exception) {
                notice = "Import failed: ${e.message ?: "Unknown error"}"
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (!setupComplete) {
                if (stage == "pin") {
                    AuthScaffold("Welcome to Rudrax Vault", "Set a PIN (4–12 digits)") {
                        OutlinedTextField(setupPin, { setupPin = it.filter(Char::isDigit).take(12) },
                            label = { Text("Create PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(12) },
                            label = { Text("Confirm PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (setupPin.length < 4) error = "PIN must contain at least 4 digits"
                            else if (setupPin != confirmPin) error = "PINs do not match"
                            else { error = ""; stage = "pattern" }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Continue to Pattern") }
                        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                    }
                } else {
                    AuthScaffold("Create Pattern", "Tap at least 4 dots, then confirm it") {
                        PatternPad(pattern) { pattern = it }
                        Text("Selected dots: ${pattern.size}", color = Muted)
                        Button(onClick = {
                            if (pattern.distinct().size < 4) error = "Use at least 4 different dots"
                            else { setupPattern = pattern; pattern = emptyList(); stage = "confirm_pattern"; error = "" }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save Pattern") }
                        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                    }
                }
            } else if (!unlocked) {
                AuthScaffold("Rudrax Vault", "Unlock your private files") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = authMode == "PIN", onClick = { authMode = "PIN"; error = "" }, label = { Text("PIN") })
                        FilterChip(selected = authMode == "Pattern", onClick = { authMode = "Pattern"; error = "" }, label = { Text("Pattern") })
                    }
                    if (authMode == "PIN") {
                        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(12) },
                            label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(),
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (verifySecret(pin, prefs.getString("pin_hash", "") ?: "", prefs.getString("pin_salt", "") ?: "")) {
                                unlocked = true; pin = ""; error = ""
                            } else error = "Incorrect PIN"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
                    } else {
                        PatternPad(pattern) { pattern = it }
                        Button(onClick = {
                            if (verifySecret(pattern.joinToString(","), prefs.getString("pattern_hash", "") ?: "", prefs.getString("pattern_salt", "") ?: "")) {
                                unlocked = true; pattern = emptyList(); error = ""
                            } else { error = "Incorrect pattern"; pattern = emptyList() }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Unlock with Pattern") }
                    }
                    if (error.isNotEmpty()) Text(error, color = Color(0xFFFF7777))
                }
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF0B0C14), Color(0xFF11101F), Color(0xFF0B0C14)))
                    )
                ) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Box(Modifier.size(48.dp).background(
                                Brush.linearGradient(listOf(Color(0xFFB69AFF), Color(0xFF6D28D9))),
                                RoundedCornerShape(16.dp)
                            ), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Rudrax Vault", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                                Text("Your private space", color = Muted, fontSize = 12.sp)
                            }
                            IconButton(onClick = { unlocked = false; notice = "" }) {
                                Icon(Icons.Filled.Lock, contentDescription = "Lock vault", tint = Color(0xFFB69AFF))
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF39236A), Color(0xFF211A3C), Color(0xFF171526))))
                                .border(1.dp, Color(0x558B5CF6), RoundedCornerShape(24.dp))
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("PRIVATE BY DESIGN", color = Color(0xFFD0BFFF), fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Keep your moments\\njust for you.", fontSize = 22.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(Modifier.height(8.dp))
                                Text("AES encrypted • Stored on device", color = Color(0xFFC2BAD8), fontSize = 11.sp)
                            }
                            Box(Modifier.size(72.dp).background(Color(0x338B5CF6), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color(0xFFD8C8FF), modifier = Modifier.size(38.dp))
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            StatTile("PRIVATE FILES", items.size.toString(), Icons.Filled.Security, Modifier.weight(1f))
                            StatTile("PHOTOS", items.count { it.mime.startsWith("image/") }.toString(), Icons.Filled.Photo, Modifier.weight(1f))
                            StatTile("VIDEOS", items.count { it.mime.startsWith("video/") }.toString(), Icons.Filled.Videocam, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = { picker.launch(arrayOf("image/*", "video/*")) },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Add photos & videos", fontWeight = FontWeight.Bold)
                        }
                        Text("Files are encrypted before being stored in your vault.", color = Muted, fontSize = 11.sp,
                            modifier = Modifier.padding(top = 8.dp, bottom = 10.dp))
                        AnimatedVisibility(visible = notice.isNotEmpty(), enter = fadeIn() + slideInVertically(), exit = fadeOut()) {
                            Text(notice, color = Color(0xFFD0BFFF), fontSize = 12.sp,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                            Text("Your vault", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
                            Text("${items.size} items", color = Muted, fontSize = 12.sp)
                        }
                        if (items.isEmpty()) {
                            Column(
                                Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(22.dp))
                                    .background(Color(0xFF171825)).border(1.dp, Color(0x223F3A55), RoundedCornerShape(22.dp))
                                    .padding(vertical = 26.dp, horizontal = 18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Color(0xFFB69AFF), modifier = Modifier.size(38.dp))
                                Spacer(Modifier.height(10.dp))
                                Text("Your vault is empty", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                Text("Add your first photo or video to get started.", color = Muted, fontSize = 12.sp)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                items(items, key = { it.id }) { item ->
                                    Row(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                            .background(Color(0xFF191A28))
                                            .border(1.dp, Color(0x223F3A55), RoundedCornerShape(18.dp))
                                            .padding(horizontal = 12.dp, vertical = 13.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(Modifier.size(44.dp).background(Color(0x338B5CF6), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                            Icon(if (item.mime.startsWith("video/")) Icons.Filled.PlayCircle else Icons.Filled.Photo,
                                                contentDescription = null, tint = Color(0xFFD0BFFF), modifier = Modifier.size(25.dp))
                                        }
                                        Spacer(Modifier.width(11.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(item.name, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1)
                                            Text("${if (item.mime.startsWith("video/")) "VIDEO" else "PHOTO"}  •  ${formatSize(item.size)}",
                                                color = Muted, fontSize = 11.sp)
                                        }
                                        IconButton(onClick = {
                                            try { openDecrypted(context, item); notice = "Opened ${item.name}" }
                                            catch (e: Exception) { notice = "Could not open file: ${e.message}" }
                                        }) { Icon(Icons.Filled.PlayCircle, contentDescription = "Open file", tint = Color(0xFFB69AFF)) }
                                        IconButton(onClick = {
                                            File(context.filesDir, "vault/${item.id}.rv").delete()
                                            removeItem(prefs, item.id)
                                            items = loadItems(prefs)
                                            notice = "File deleted from vault"
                                        }) { Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete from vault", tint = Color(0xFFFF8B9A)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (!setupComplete && stage == "confirm_pattern") {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Confirm Pattern") },
                    text = { Column {
                        Text("Draw the same pattern again.")
                        PatternPad(confirmPattern) { confirmPattern = it }
                    } },
                    confirmButton = {
                        TextButton(onClick = {
                            if (confirmPattern.distinct().size < 4 || confirmPattern != setupPattern) {
                                error = "Patterns do not match"; confirmPattern = emptyList()
                            } else {
                                saveSecret(prefs, "pin", setupPin)
                                saveSecret(prefs, "pattern", setupPattern.joinToString(","))
                                prefs.edit().putBoolean("setup_complete", true).apply()
                                setupComplete = true; unlocked = true
                                stage = "pin"; confirmPattern = emptyList()
                            }
                        }) { Text("Finish Setup") }
                    },
                    dismissButton = { TextButton(onClick = { stage = "pattern"; confirmPattern = emptyList() }) { Text("Back") }
                    }
                )
            }

            if (pendingDelete != null) {
                AlertDialog(
                    onDismissRequest = { pendingDelete = null },
                    title = { Text("Delete original file?") },
                    text = { Text("An encrypted copy of \"$pendingDeleteName\" is saved. Do you want to delete the original from its source? This may not work for every gallery/provider.") },
                    confirmButton = {
                        TextButton(onClick = {
                            val uri = pendingDelete
                            try {
                                if (uri != null) {
                                    val deleted = try { context.contentResolver.delete(uri, null, null) > 0 }
                                    catch (_: Exception) { false }
                                    notice = if (deleted) "Original deleted; encrypted copy remains in vault."
                                    else "Vault copy is safe. The original was not deleted; remove it manually from Gallery if desired."
                                }
                            } finally { pendingDelete = null }
                        }) { Text("Delete Original", color = Color(0xFFFF7777)) }
                    },
                    dismissButton = { TextButton(onClick = { pendingDelete = null; notice = "Original kept in Gallery." }) { Text("Keep Original") } }
                )
            }
        }
    }
}



@Composable
private fun StatTile(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF191A28))
            .border(1.dp, Color(0x223F3A55), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFFB69AFF), modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 0.5.sp, maxLines = 1)
    }
}

@Composable
private fun AuthScaffold(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    val pulse by animateFloatAsState(
        targetValue = 1f, animationSpec = tween(900, easing = FastOutSlowInEasing), label = "logoPulse"
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF0B0C14), Color(0xFF19132D), Color(0xFF0B0C14)))
        )
    ) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 65.dp, end = 22.dp).size(170.dp)
            .background(Color(0x228B5CF6), CircleShape))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 70.dp).size(210.dp)
            .background(Color(0x168B5CF6), CircleShape))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 28.dp).imePadding(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(88.dp).scale(pulse)
                    .background(Brush.linearGradient(listOf(Color(0xFFB69AFF), Color(0xFF6D28D9))), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Security, contentDescription = "Rudrax Vault", tint = Color.White, modifier = Modifier.size(46.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text(title, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(subtitle, color = Color(0xFFB9B5CA), fontSize = 14.sp,
                modifier = Modifier.padding(top = 9.dp, bottom = 24.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(Color(0xDD191A29))
                    .border(1.dp, Color(0x448B5CF6), RoundedCornerShape(26.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                content = content
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color(0xFFB69AFF), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("PRIVATE STORAGE  •  ON THIS DEVICE", fontSize = 10.sp, color = Color(0xFF9C97B1), letterSpacing = 1.sp)
            }
        }
    }
}
@Composable
private fun PatternPad(selected: List<Int>, onChange: (List<Int>) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.animateContentSize()) {
        for (r in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp), modifier = Modifier.padding(vertical = 9.dp)) {
                for (c in 0..2) {
                    val index = r * 3 + c
                    val active = selected.contains(index)
                    Box(
                        Modifier.size(52.dp).border(1.dp, if (active) Color(0xFFD0BFFF) else Color(0x665C5670), CircleShape)
                            .background(if (active) Violet else Color(0xFF252338), CircleShape)
                            .clickable {
                                onChange(if (active) selected.filter { it != index } else selected + index)
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(if (active) "✓" else "•", color = Color.White, fontSize = if (active) 20.sp else 25.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Text("Tap dots in order", color = Muted, fontSize = 12.sp)
    }
}

private fun saveSecret(prefs: android.content.SharedPreferences, key: String, value: String) {
    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
    prefs.edit().putString("${key}_salt", salt.joinToString("") { "%02x".format(it) })
        .putString("${key}_hash", hash(value, salt)).apply()
}
private fun verifySecret(value: String, expected: String, saltHex: String): Boolean {
    if (expected.isBlank() || saltHex.isBlank()) return false
    val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    return MessageDigest.isEqual(hash(value, salt).toByteArray(), expected.toByteArray())
}
private fun hash(value: String, salt: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(salt + value.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
}

private fun vaultDir(context: Context): File = File(context.filesDir, "vault").apply { mkdirs() }

private fun getVaultKey(): SecretKey {
    val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val existing = ks.getKey("RudraxVaultKey", null) as? SecretKey
    if (existing != null) return existing
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(KeyGenParameterSpec.Builder(
        "RudraxVaultKey",
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
    ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true)
        .build())
    return generator.generateKey()
}

private fun importEncrypted(context: Context, uri: Uri): VaultItem {
    val resolver = context.contentResolver
    val displayName = queryName(resolver, uri) ?: "private_${System.currentTimeMillis()}"
    val mime = resolver.getType(uri) ?: "application/octet-stream"
    val id = java.util.UUID.randomUUID().toString()
    val dest = File(vaultDir(context), "$id.rv")
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getVaultKey())
    resolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Unable to read selected file" }
        FileOutputStream(dest).use { fileOut ->
            fileOut.write(cipher.iv)
            CipherOutputStream(fileOut, cipher).use { encryptedOut -> input.copyTo(encryptedOut) }
        }
    }
    val item = VaultItem(id, displayName, mime, dest.length())
    val prefs = context.getSharedPreferences("rudrax_vault", Context.MODE_PRIVATE)
    val array = JSONArray(prefs.getString("items", "[]"))
    array.put(JSONObject().put("id", item.id).put("name", item.name).put("mime", item.mime).put("size", item.size))
    prefs.edit().putString("items", array.toString()).apply()
    return item
}

private fun loadItems(prefs: android.content.SharedPreferences): List<VaultItem> {
    val out = mutableListOf<VaultItem>()
    val arr = JSONArray(prefs.getString("items", "[]"))
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        out += VaultItem(o.optString("id"), o.optString("name"), o.optString("mime"), o.optLong("size"))
    }
    return out
}
private fun removeItem(prefs: android.content.SharedPreferences, id: String) {
    val arr = JSONArray()
    loadItems(prefs).filter { it.id != id }.forEach {
        arr.put(JSONObject().put("id", it.id).put("name", it.name).put("mime", it.mime).put("size", it.size))
    }
    prefs.edit().putString("items", arr.toString()).apply()
}
private fun queryName(resolver: ContentResolver, uri: Uri): String? {
    return try {
        resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }
}

private fun decryptToCache(context: Context, item: VaultItem): File {
    val encrypted = File(vaultDir(context), "${item.id}.rv")
    require(encrypted.exists()) { "Encrypted file missing" }
    val temp = File(context.cacheDir, "preview_${item.id}")
    FileInputStream(encrypted).use { fileIn ->
        val iv = ByteArray(12)
        if (fileIn.read(iv) != 12) throw IOException("Invalid encrypted file")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getVaultKey(), GCMParameterSpec(128, iv))
        CipherInputStream(fileIn, cipher).use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        }
    }
    return temp
}
private fun openDecrypted(context: Context, item: VaultItem) {
    val temp = decryptToCache(context, item)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", temp)
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
private fun formatSize(size: Long): String = when {
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "${size / 1024} KB"
    else -> String.format("%.1f MB", size / (1024.0 * 1024.0))
}
