# Rudrax Vault (Kotlin + Jetpack Compose)

A local-only Android photo/video vault starter project.

## Features
- First-launch setup for a 4–12 digit PIN and a pattern (at least 4 dots).
- Unlock with either PIN or pattern.
- Files are encrypted with AES-GCM using an Android Keystore AES key.
- Uses Android's document picker; no broad gallery permission is required.
- Encrypted files live in the app-private `files/vault` directory.
- No server, Firebase, or online database.
- Optional prompt to delete the source after the encrypted copy is created.

## Requirements
- Android Studio Ladybug or newer recommended.
- JDK 17.
- Android SDK Platform 35 installed.
- Android Gradle Plugin 8.7.3 / Gradle 8.9 compatible wrapper.

## Open and run
1. Extract this ZIP.
2. Open the `RudraxVault` folder in Android Studio.
3. Allow Gradle sync. If prompted to create/download a Gradle wrapper, use Gradle 8.9.
4. Connect an Android phone with USB debugging enabled, or start an emulator (API 26+).
5. Press Run.

## Important security and implementation notes
- This is a starter project; build and test it on your device before storing important files.
- Android Keystore protects the encryption key, but the key is not derived from the PIN/pattern. The app's UI gate is local authentication; a rooted/compromised device or app-level bypass can affect protection.
- The PIN and pattern are stored as salted SHA-256 hashes. For production, prefer a memory-hard password KDF (e.g. scrypt/Argon2 via a vetted library) and add throttling / lockout.
- Android secure storage is app-private. Uninstalling the app or clearing app data removes the vault files and key, so encrypted files may become unrecoverable. Back up files only through a carefully designed encrypted export flow.
- Opening a file temporarily decrypts it into app cache so another viewer app can display/play it. Cache files are not guaranteed to be securely erased; clear them on lock and app exit for a production release.
- Deleting the original source is best-effort and depends on the selected document provider. The app asks first, but may be unable to delete files selected from some gallery providers. If it fails, delete the original manually after confirming the vault copy opens correctly.
- The pattern pad is a tap-sequence prototype, not a continuous drag-to-draw pattern UI.
- The metadata (filename, MIME type, approximate encrypted size) is stored in private SharedPreferences, not encrypted. Do not use highly sensitive filenames in this starter version.
- This code is provided as a starting point, not a security-audited product.

## Project structure
- `app/src/main/java/in/rudrax/vault/MainActivity.kt` - UI, auth, import, AES-GCM encryption/decryption
- `app/src/main/AndroidManifest.xml` - app manifest and FileProvider
- `app/src/main/res/xml/file_paths.xml` - temporary preview sharing paths
